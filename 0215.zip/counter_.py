'''

뉴스 기사를 읽어 키워드 빈도를 계산하는 프로그램

이 때 빈도는 제목과 부제 각각 단어의 합임

'''



import csv



TITLE = 0

SUBTITLE = 1

DATE = -2

TIME = -1



csvFile = "./newsList_raw"



f = open(csvFile + ".csv", 'r', encoding="utf8", newline="")

c = csv.reader(f)



wordList = {"코로나": 0, "우한 폐렴": 0, "제약":0, "바이오":0, "백신":0, "바이러스":0, "확진":0, "누적":0, "사망":0, "신규":0}

listToWrite = [[i for i in wordList.keys()]]



for news in c:

    for word in wordList.keys():

        wordList[word] += (news[TITLE].count(word) + news[SUBTITLE].count(word))

    listToWrite.append(

        list(wordList.values()) + [news[DATE], news[TIME]]

        )

    

    #wordList item을 모두 0으로 초기화

    for word in wordList.keys():

        wordList[word] = 0



with open(csvFile + '_count.csv', 'w', encoding="utf8", newline="") as w:

    csv.writer(w).writerows(listToWrite)



f.close()
