'''
뉴스 기사를 읽어 키워드 빈도를 계산하는 프로그램
이 때 빈도는 제목과 부제 각각 단어의 합임
'''

import csv

csvFile = "./Empty File.csv"

f = open(csvFile, 'r', encoding="utf8", newline="")
c = csv.reader(f)

wordList = {"코로나": 0, "우한 폐렴": 0}
listToWrite = [[i for i in wordList.keys()]]

for news in c:
    for word in wordList.keys():
        wordList[word] += ( news[0].count(word) + news[1].count(word) )
    listToWrite.append(list(wordList.values()))
    
    #wordList item을 모두 0으로 초기화
    for word in wordList.keys():
        wordList[word] = 0

with open(csvFile[:-4] + '_.csv', 'w', encoding="utf8", newline="") as w:
    csv.writer(w).writerows(listToWrite)

f.close().close()